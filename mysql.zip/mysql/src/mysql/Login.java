package mysql;

import java.awt.BorderLayout;
import java.sql.*; 
import java.awt.EventQueue;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import java.awt.Font;
import javax.swing.UIManager;
import java.awt.SystemColor;
import javax.swing.border.LineBorder;
import java.awt.Color;

public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField user;
	private JPasswordField pass;
	


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
					frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public void close() {
		WindowEvent winClosingEvent = new WindowEvent (this,WindowEvent.WINDOW_CLOSING);
		Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(winClosingEvent);
	}
	public Login() {
		setBackground(UIManager.getColor("Desktop.background"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 312, 301);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.window);
		contentPane.setBorder(new LineBorder(SystemColor.window, 2));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblLoginPage = new JLabel("Login Page");
		lblLoginPage.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		lblLoginPage.setBounds(6, 6, 286, 45);
		contentPane.add(lblLoginPage);
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblUsername.setBounds(95, 60, 86, 16);
		contentPane.add(lblUsername);
		
		user = new JTextField();
		user.setBounds(36, 88, 212, 24);
		contentPane.add(user);
		user.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblPassword.setBounds(95, 124, 86, 16);
		contentPane.add(lblPassword);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library","root","NEWPASS");
					Statement stmt = con.createStatement();
					String sql = "Select * from Accounts where Username='"+user.getText()+"' and Password='" +pass.getText().toString()+ "'";
					ResultSet rs = stmt.executeQuery(sql);
					if(rs.next()) {
						JOptionPane.showMessageDialog(null, "Login Successfully!");
						close();
					HomePage ho=new HomePage();
		            ho.setVisible(true);
		            
		    }
					else
						JOptionPane.showMessageDialog(null, "Incorrect username or password");
				}catch(Exception e){
					System.out.print(e);
				}
			}
		});
		btnLogin.setBounds(23, 194, 92, 25);
		contentPane.add(btnLogin);
		
		pass = new JPasswordField();
		pass.setBounds(36, 152, 212, 26);
		contentPane.add(pass);
		
		JButton btnForgot = new JButton("Forgot "); //accidentally made it signup java
		btnForgot.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				Signup sp = new Signup();
				sp.setVisible(true);
			}
		});
		btnForgot.setBounds(84, 226, 117, 29);
		contentPane.add(btnForgot);
		
		JButton btnSignup = new JButton("Signup");
		btnSignup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				forgot fg = new forgot();
				fg.setVisible(true);
			}
		});
		btnSignup.setBounds(149, 193, 104, 27);
		contentPane.add(btnSignup);
		
		JLabel lblNewLabel = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("/lock.png")).getImage();
		lblNewLabel.setIcon(new ImageIcon(img));
		lblNewLabel.setBounds(110, 184, 30, 36);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("");
		Image img2 = new ImageIcon(this.getClass().getResource("/login-2.png")).getImage();
		lblNewLabel.setIcon(new ImageIcon(img2));
		lblNewLabel_1.setBounds(84, 190, 25, 24);
		contentPane.add(lblNewLabel_1);
		
		JLabel lbllogin = new JLabel("");
		Image img3 = new ImageIcon(this.getClass().getResource("/user.png")).getImage();
		lbllogin.setIcon(new ImageIcon(img3));
		lbllogin.setBounds(176, 49, 38, 36);
		contentPane.add(lbllogin);
		
		JLabel lblsignup = new JLabel("");
		Image img4 = new ImageIcon(this.getClass().getResource("/user-2.png")).getImage();
		lblsignup.setIcon(new ImageIcon(img4));
		lblsignup.setBounds(251, 184, 30, 36);
		contentPane.add(lblsignup);
		
		JLabel lblforgot = new JLabel("");
		Image img5 = new ImageIcon(this.getClass().getResource("/forgot.png")).getImage();
		lblforgot.setIcon(new ImageIcon(img5));
		lblforgot.setBounds(199, 226, 30, 24);
		contentPane.add(lblforgot);
		
		JLabel lblpass = new JLabel("");
		Image img6 = new ImageIcon(this.getClass().getResource("/key.png")).getImage();
		lblpass.setIcon(new ImageIcon(img6));
		lblpass.setBounds(176, 112, 44, 36);
		contentPane.add(lblpass);
	
	}
}
