package mysql;
import java.sql.*;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class forgot extends JFrame {

	private JPanel contentPane;
	private JTextField txtusername;
	private JTextField txtname;
	private JTextField txtpassword;
	private JTextField txtanswer;
	private JTextField txtsecurity;
	private JTextField usrID;

	/**
	 * Launch the application.
	 */
	public void theQuery (String query) {
		Statement st = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library","root","NEWPASS");
			st = con.createStatement();
			st.executeUpdate(query);
			JOptionPane.showMessageDialog(null,"Query executed!");
		}catch(Exception ex) {
			JOptionPane.showMessageDialog(null,ex.getMessage());
		}
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					forgot frame = new forgot();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public forgot() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 474, 356);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblName = new JLabel("Name");
		lblName.setBounds(18, 94, 61, 16);
		contentPane.add(lblName);
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setBounds(18, 53, 76, 16);
		contentPane.add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(18, 143, 61, 16);
		contentPane.add(lblPassword);
		
		JLabel lblSecurityQuestio = new JLabel("Security Question");
		lblSecurityQuestio.setBounds(18, 194, 113, 16);
		contentPane.add(lblSecurityQuestio);
		
		JLabel lblAnswer = new JLabel("Answer");
		lblAnswer.setBounds(28, 246, 61, 16);
		contentPane.add(lblAnswer);
		
		txtusername = new JTextField();
		txtusername.setBounds(138, 48, 231, 26);
		contentPane.add(txtusername);
		txtusername.setColumns(10);
		
		txtname = new JTextField();
		txtname.setBounds(138, 89, 231, 26);
		contentPane.add(txtname);
		txtname.setColumns(10);
		
		txtpassword = new JTextField();
		txtpassword.setBounds(138, 138, 231, 26);
		contentPane.add(txtpassword);
		txtpassword.setColumns(10);
		
		txtanswer = new JTextField();
		txtanswer.setBounds(143, 241, 226, 26);
		contentPane.add(txtanswer);
		txtanswer.setColumns(10);
		
		JButton btnCreate = new JButton("Create");
		btnCreate.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
				try {
					 theQuery("insert into Accounts (UserID,Username, Name, Password, Sec_Q, Answer) values ('"+usrID.getText()+"','"+txtusername.getText()+"', '"+txtname.getText()+"','"+txtpassword.getText()+"','"+txtsecurity.getText()+"','"+txtanswer.getText()+"')");
						      // create the mysql insert prepared statement
						      System.out.println("User account created!");
						      usrID.setText("");
						      txtusername.setText("");
						      txtname.setText("");
						      txtpassword.setText("");
						      txtsecurity.setText("");
						      txtanswer.setText("");
				}catch(Exception e1) {
					System.out.print("Problem occured!");
				}
				
			}
		});
		btnCreate.setBounds(94, 287, 117, 29);
		contentPane.add(btnCreate);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				Login ln= new Login();
				ln.setVisible(true);
			}
		});
		btnBack.setBounds(262, 287, 117, 29);
		contentPane.add(btnBack);
		
		txtsecurity = new JTextField();
		txtsecurity.setBounds(143, 189, 226, 26);
		contentPane.add(txtsecurity);
		txtsecurity.setColumns(10);
		
		JLabel lblUserId = new JLabel("User ID");
		lblUserId.setBounds(18, 10, 61, 16);
		contentPane.add(lblUserId);
		
		usrID = new JTextField();
		usrID.setBounds(138, 7, 231, 21);
		contentPane.add(usrID);
		usrID.setColumns(10);
	}
}
