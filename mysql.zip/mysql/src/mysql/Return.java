package mysql;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class Return extends JFrame {

	private JPanel contentPane;
	private JTextField txtuserid;
	private JTextField usrname;
	private JTextField name;
	private JTextField txtbookid;
	private JTextField bname;
	private JTextField pub;
	private JTextField nop;
	private JTextField txtbook;

	/**
	 * Launch the application.
	 */
	ResultSet rs,rss;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Return frame = new Return();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Return() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 390);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUserId = new JLabel("User ID");
		lblUserId.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		lblUserId.setBounds(19, 38, 61, 16);
		contentPane.add(lblUserId);
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		lblUsername.setBounds(19, 66, 73, 16);
		contentPane.add(lblUsername);
		
		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		lblName.setBounds(19, 96, 61, 16);
		contentPane.add(lblName);
		
		JLabel lblBookId = new JLabel("Book ID");
		lblBookId.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		lblBookId.setBounds(345, 38, 61, 16);
		contentPane.add(lblBookId);
		
		JLabel lblBookName = new JLabel("Book Name");
		lblBookName.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		lblBookName.setBounds(345, 66, 73, 16);
		contentPane.add(lblBookName);
		
		JLabel lblPublisher = new JLabel("Publisher");
		lblPublisher.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		lblPublisher.setBounds(345, 96, 61, 16);
		contentPane.add(lblPublisher);
		
		JLabel lblNumberOfPages = new JLabel("Number of Pages");
		lblNumberOfPages.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		lblNumberOfPages.setBounds(345, 124, 123, 16);
		contentPane.add(lblNumberOfPages);
		
		JLabel lblBookType = new JLabel("Book Type");
		lblBookType.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		lblBookType.setBounds(345, 152, 90, 16);
		contentPane.add(lblBookType);
		
		txtuserid = new JTextField();
		txtuserid.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		txtuserid.setBounds(105, 33, 130, 26);
		contentPane.add(txtuserid);
		txtuserid.setColumns(10);
		
		usrname = new JTextField();
		usrname.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		usrname.setBounds(104, 61, 130, 26);
		contentPane.add(usrname);
		usrname.setColumns(10);
		
		name = new JTextField();
		name.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		name.setBounds(105, 91, 130, 26);
		contentPane.add(name);
		name.setColumns(10);
		
		txtbookid = new JTextField();
		txtbookid.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		txtbookid.setBounds(467, 33, 130, 26);
		contentPane.add(txtbookid);
		txtbookid.setColumns(10);
		
		bname = new JTextField();
		bname.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		bname.setBounds(467, 61, 130, 26);
		contentPane.add(bname);
		bname.setColumns(10);
		
		pub = new JTextField();
		pub.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		pub.setBounds(467, 91, 130, 26);
		contentPane.add(pub);
		pub.setColumns(10);
		
		nop = new JTextField();
		nop.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		nop.setBounds(467, 119, 130, 26);
		contentPane.add(nop);
		nop.setColumns(10);
		
		txtbook = new JTextField();
		txtbook.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		txtbook.setBounds(467, 147, 130, 26);
		contentPane.add(txtbook);
		txtbook.setColumns(10);
		
		JButton btnReturn = new JButton("Return");
		btnReturn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Return book
				try {
					Class.forName("com.mysql.jdbc.Driver").newInstance();
					//System.out.println("Installed");
					Connection conn1= DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "root", "NEWPASS");
					Statement stmt1=conn1.createStatement();
					
					int idbook = Integer.parseInt(txtbookid.getText());
				rss = stmt1.executeQuery("delete from Borrow where bookid="+ idbook);
				while(rss.next()){
					txtuserid.setText(rss.getString("UserID"));
					usrname.setText(rss.getString("Username"));
					name.setText(rss.getString("Name"));
					txtbookid.setText(rss.getString("bookid"));
					bname.setText(rss.getString("bname"));
					pub.setText(rss.getString("publisher"));
					nop.setText(rss.getString("nop"));
					txtbook.setText(rss.getString("bname"));
					JOptionPane.showMessageDialog(null,"Book returned!");
				}
				}catch(Exception exep) {
					JOptionPane.showMessageDialog(null,"An error occured please try again!");
					
				}
			}
		});
		btnReturn.setBounds(205, 221, 117, 29);
		contentPane.add(btnReturn);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				HomePage hm = new HomePage();
				hm.setVisible(true);
			}
		});
		btnBack.setBounds(334, 221, 117, 29);
		contentPane.add(btnBack);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//search books
			
				//String namebook = String.valueOf(txtname.getText());
				try {
					Class.forName("com.mysql.jdbc.Driver").newInstance();
					//System.out.println("Installed");
					Connection conn1= DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "root", "NEWPASS");
					Statement stmt1=conn1.createStatement();
					
					int idbook = Integer.parseInt(txtbookid.getText());
				rss = stmt1.executeQuery("select * from Borrow where bookid="+ idbook);
				while(rss.next()){
					txtuserid.setText(rss.getString("UserID"));
					usrname.setText(rss.getString("Username"));
					name.setText(rss.getString("Name"));
					txtbookid.setText(rss.getString("bookid"));
					bname.setText(rss.getString("bname"));
					pub.setText(rss.getString("publisher"));
					nop.setText(rss.getString("nop"));
					txtbook.setText(rss.getString("bname"));
					JOptionPane.showMessageDialog(null,"Borrowed book found!");
				}
				}catch(Exception exep) {
					JOptionPane.showMessageDialog(null,"An error occured please try again!");
					
				}
			}
		});
		btnSearch.setBounds(115, 139, 117, 29);
		contentPane.add(btnSearch);
	}

}
