package mysql;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class Signup extends JFrame {

	private JPanel contentPane;
	private JTextField usernametxt;
	private JTextField nametxt;
	private JTextField textField_2;
	private JTextField passwordtxt;
	private JTextField txtid;

	/**
	 * Launch the application.
	 */
	ResultSet rs,rss;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Signup frame = new Signup();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Signup() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setBounds(18, 32, 84, 25);
		contentPane.add(lblUsername);
		
		JLabel lblSecurityQuestion = new JLabel("Security Question");
		lblSecurityQuestion.setBounds(18, 161, 111, 25);
		contentPane.add(lblSecurityQuestion);
		
		JLabel lblAnswer = new JLabel("Answer");
		lblAnswer.setBounds(18, 195, 61, 16);
		contentPane.add(lblAnswer);
		
		JLabel lblName = new JLabel("Name");
		lblName.setBounds(18, 133, 61, 16);
		contentPane.add(lblName);
		
		usernametxt = new JTextField();
		usernametxt.setBounds(94, 31, 130, 26);
		contentPane.add(usernametxt);
		usernametxt.setColumns(10);
		
		nametxt = new JTextField();
		nametxt.setBounds(94, 123, 130, 26);
		contentPane.add(nametxt);
		nametxt.setColumns(10);
		
		JTextArea securitytxt = new JTextArea();
		securitytxt.setBounds(141, 165, 161, 21);
		contentPane.add(securitytxt);
		
		textField_2 = new JTextField();
		textField_2.setBounds(141, 190, 130, 26);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(18, 223, 61, 16);
		contentPane.add(lblPassword);
		
		passwordtxt = new JTextField();
		passwordtxt.setBounds(141, 218, 130, 26);
		contentPane.add(passwordtxt);
		passwordtxt.setColumns(10);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//search security question
				try{
					Class.forName("com.mysql.jdbc.Driver").newInstance();
					//System.out.println("Installed");
					Connection conn1= DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "root", "NEWPASS");
					Statement stmt1=conn1.createStatement();
					
					int userid = Integer.parseInt(txtid.getText());
					//String namebook = String.valueOf(txtname.getText());
					rss = stmt1.executeQuery("SELECT Sec_Q FROM Accounts WHERE UserID="+ userid);
					while(rss.next()){
						securitytxt.setText(rss.getString("Sec_Q"));
					}
					
					
				}catch(Exception ex){
					System.out.println("Problem occured.");
				
				}
			}
		   }); 
		
		btnSearch.setBounds(227, 83, 117, 29);
		contentPane.add(btnSearch);
		
		JButton btnRetrieve = new JButton("Retrieve");
		btnRetrieve.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//see all the information
				try{
					Class.forName("com.mysql.jdbc.Driver").newInstance();
					//System.out.println("Installed");
					Connection conn1= DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "root", "NEWPASS");
					Statement stmt1=conn1.createStatement();
					
					int userid = Integer.parseInt(txtid.getText());
					//String namebook = String.valueOf(txtname.getText());
					rss = stmt1.executeQuery("SELECT * FROM Accounts WHERE Answer="+ securitytxt);
					while(rss.next()){
						txtid.setText("UserID");
						usernametxt.setText(rss.getString("Username"));
						nametxt.setText(rss.getString("Name"));
						securitytxt.setText(rss.getString("Sec_Q"));
						passwordtxt.setText(rss.getString("Password"));
					}
					
					
				}catch(Exception ex){
					System.out.println("Problem occured.");
				
				}
			}
		   }); 
		btnRetrieve.setBounds(310, 160, 117, 29);
		contentPane.add(btnRetrieve);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				Login ln=new Login();
	            ln.setVisible(true);
			}
		});
		btnBack.setBounds(310, 210, 117, 29);
		contentPane.add(btnBack);
		
		JLabel lblNewLabel = new JLabel("User ID");
		lblNewLabel.setBounds(18, 88, 61, 16);
		contentPane.add(lblNewLabel);
		
		txtid = new JTextField();
		txtid.setBounds(94, 85, 130, 26);
		contentPane.add(txtid);
		txtid.setColumns(10);
	}
}
