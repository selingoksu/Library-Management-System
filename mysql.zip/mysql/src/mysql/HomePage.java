package mysql;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JDesktopPane;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JToolBar;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class HomePage extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HomePage frame = new HomePage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public HomePage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 720, 416);
		contentPane = new JPanel();
		contentPane.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		JButton exit;
		JButton help;
		JButton about;
		JToolBar toolBar = new JToolBar();
		toolBar.setBounds(6, 6, 708, 20);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		contentPane.add(toolBar);
		about=new JButton("About");
		
		about.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			JOptionPane.showMessageDialog(null, "Welcome to library management system. Creator Aysel Selin Goksu.");
			}
			
		});
		help=new JButton("Help");
		
		help.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			JOptionPane.showMessageDialog(null, "Please refer to the ID of books to make search!");
			}
			
		});
		exit=new JButton("Exit");
		exit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 System.exit(0);
			}
			
		});
		
		toolBar.add(help);
		toolBar.add(about);
		toolBar.add(exit);
		getContentPane().add(toolBar);
		
		JDesktopPane desktopPane = new JDesktopPane();
		desktopPane.setBounds(0, 27, 714, 361);
		contentPane.add(desktopPane);
		
		JButton btnSearchBooks = new JButton("Search Books");
		btnSearchBooks.setBounds(142, 146, 127, 29);
		desktopPane.add(btnSearchBooks);
		btnSearchBooks.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		
		JButton btnBorrow = new JButton("Borrow");
		btnBorrow.setBounds(142, 315, 127, 29);
		desktopPane.add(btnBorrow);
		btnBorrow.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		
		JButton btnReturn = new JButton("Return");
		btnReturn.setBounds(466, 146, 127, 29);
		desktopPane.add(btnReturn);
		btnReturn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				Return rn=new Return();
	            rn.setVisible(true);
			}
		});
		btnReturn.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		
		JButton btnAddBook = new JButton("Add Book");
		btnAddBook.setBounds(466, 315, 127, 29);
		desktopPane.add(btnAddBook);
		btnAddBook.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		
		JLabel image1lbl = new JLabel("");
		Image img2 = new ImageIcon(this.getClass().getResource("/book-2.png")).getImage();
		image1lbl.setIcon(new ImageIcon(img2));
		image1lbl.setBounds(142, 187, 137, 128);
		desktopPane.add(image1lbl);
		
		JLabel lbl2image = new JLabel("");
		Image img3 = new ImageIcon(this.getClass().getResource("/research.png")).getImage();
		lbl2image.setIcon(new ImageIcon(img3));
		lbl2image.setBounds(142, 19, 137, 128);
		desktopPane.add(lbl2image);
		
		JLabel lbladdbook = new JLabel("");
		Image img4 = new ImageIcon(this.getClass().getResource("/book-3.png")).getImage();
		lbladdbook.setIcon(new ImageIcon(img4));
		lbladdbook.setBounds(456, 187, 137, 128);
		desktopPane.add(lbladdbook);
		
		JLabel lblreturn = new JLabel("");
		Image img5 = new ImageIcon(this.getClass().getResource("/return.png")).getImage();
		lblreturn.setIcon(new ImageIcon(img5));
		lblreturn.setBounds(466, 19, 137, 128);
		desktopPane.add(lblreturn);
		
		
		
		btnAddBook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				AddBook ad=new AddBook();
	            ad.setVisible(true);
			}
		});
		btnBorrow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				Borrow bo=new Borrow();
	            bo.setVisible(true);
			}
		});
		btnSearchBooks.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				SearchBooks sb = new SearchBooks();
				sb.setVisible(true);
				
				
			}
		});
	
		
	}
}
