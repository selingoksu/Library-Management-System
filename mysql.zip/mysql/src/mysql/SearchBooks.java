package mysql;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTable;

public class SearchBooks extends JFrame {

	private JPanel contentPane;
	private JTextField txtid;
	private JTextField txtname;
	private JTextField pub;
	private JTextField txtnop;
	private JTextField isseue;

	ResultSet rs,rss;
	private JTable table;

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SearchBooks frame = new SearchBooks();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SearchBooks() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 451, 447);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblBookId = new JLabel("Book ID");
		lblBookId.setBounds(6, 20, 61, 16);
		contentPane.add(lblBookId);
		
		JLabel lblBookName = new JLabel("Book Name");
		lblBookName.setBounds(6, 60, 71, 16);
		contentPane.add(lblBookName);
		
		JLabel lblPublisher = new JLabel("Publisher");
		lblPublisher.setBounds(6, 100, 61, 16);
		contentPane.add(lblPublisher);
		
		JLabel lblNumberOfPages = new JLabel("Number of Pages");
		lblNumberOfPages.setBounds(6, 143, 118, 16);
		contentPane.add(lblNumberOfPages);
		
		JLabel lblIssueStatus = new JLabel("Book Type");
		lblIssueStatus.setBounds(6, 188, 98, 16);
		contentPane.add(lblIssueStatus);
		
		txtid = new JTextField();
		txtid.setBounds(131, 15, 203, 26);
		contentPane.add(txtid);
		txtid.setColumns(10);
		
		txtname = new JTextField();
		txtname.setBounds(131, 55, 203, 26);
		contentPane.add(txtname);
		txtname.setColumns(10);
		
		pub = new JTextField();
		pub.setBounds(131, 95, 203, 26);
		contentPane.add(pub);
		pub.setColumns(10);
		
		txtnop = new JTextField();
		txtnop.setBounds(131, 138, 203, 26);
		contentPane.add(txtnop);
		txtnop.setColumns(10);
		
		isseue = new JTextField();
		isseue.setBounds(131, 183, 203, 26);
		contentPane.add(isseue);
		isseue.setColumns(10);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				try{
					Class.forName("com.mysql.jdbc.Driver").newInstance();
					//System.out.println("Installed");
					Connection conn1= DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "root", "NEWPASS");
					Statement stmt1=conn1.createStatement();
					
					int idbook = Integer.parseInt(txtid.getText());
					//String namebook = String.valueOf(txtname.getText());
					rss = stmt1.executeQuery("select * from dbooks where bookid="+ idbook);
					while(rss.next()){
						txtid.setText(rss.getString("bookid"));
					    txtname.setText(rss.getString("bname"));
						pub.setText(rss.getString("publisher"));
						txtnop.setText(rss.getString("nop"));
						isseue.setText(rss.getString("booktype"));
					}
					
				}catch(Exception ex){
					System.out.println("Problem occured.");
				
				}
			}
		   }); 

		btnSearch.setBounds(340, 15, 104, 26);
		contentPane.add(btnSearch);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				HomePage hp = new HomePage();
				hp.setVisible(true);
			}
		});
		btnBack.setBounds(233, 221, 117, 29);
		contentPane.add(btnBack);
		
		JButton btnBorrowBook = new JButton("Borrow Book");
		btnBorrowBook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
					Class.forName("com.mysql.jdbc.Driver").newInstance();
					//System.out.println("Installed");
					Connection conn1= DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "root", "NEWPASS");
					Statement stmt1=conn1.createStatement();
					Statement stmt2=conn1.createStatement();
					
					int idbook = Integer.parseInt(txtid.getText());
					rss = stmt1.executeQuery("select * from books where bookid="+ idbook);
					while(rss.next()){
						txtid.setText(rss.getString("bookid"));
					    txtname.setText(rss.getString("bname"));
						pub.setText(rss.getString("publisher"));
						txtnop.setText(rss.getString("nop"));
						isseue.setText(rss.getString("issuestatus"));
						rss = stmt2.executeQuery("update books set issuesstatus='Issued' where bookid = txtid.getText()");
		                }
				}catch(Exception ex){
					System.out.println("Problem occured.");
				
				}
			}
		});
		btnBorrowBook.setBounds(49, 221, 117, 29);
		contentPane.add(btnBorrowBook);
		
		table = new JTable();
		table.setBounds(19, 398, 403, -90);
		contentPane.add(table);
	}
}
