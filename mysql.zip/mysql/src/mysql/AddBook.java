package mysql;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class AddBook extends JFrame {

	private JPanel contentPane;
	private JTextField bookid;
	private JTextField bname;
	private JTextField pub;
	private JTextField nop;
	private JTextField isseue;

	/**
	 * Launch the application.
	 */
	public void theQuery (String query) {
		Statement st = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library","root","NEWPASS");
			st = con.createStatement();
			st.executeUpdate(query);
			JOptionPane.showMessageDialog(null,"Query executed!");
		}catch(Exception ex) {
			JOptionPane.showMessageDialog(null,ex.getMessage());
		}
	}
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddBook frame = new AddBook();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AddBook() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblBookId = new JLabel("Book ID");
		lblBookId.setBounds(21, 24, 61, 16);
		contentPane.add(lblBookId);
		
		JLabel lblBookName = new JLabel("Book Name");
		lblBookName.setBounds(21, 67, 76, 16);
		contentPane.add(lblBookName);
		
		JLabel lblPublisher = new JLabel("Publisher");
		lblPublisher.setBounds(21, 115, 61, 16);
		contentPane.add(lblPublisher);
		
		JLabel lblNumberOfPages = new JLabel("Number of Pages");
		lblNumberOfPages.setBounds(21, 163, 107, 16);
		contentPane.add(lblNumberOfPages);
		
		JLabel lblIssueStatus = new JLabel("Book Type");
		lblIssueStatus.setBounds(21, 201, 96, 16);
		contentPane.add(lblIssueStatus);
		
		bookid = new JTextField();
		bookid.setBounds(137, 19, 229, 26);
		contentPane.add(bookid);
		bookid.setColumns(10);
		
		bname = new JTextField();
		bname.setBounds(139, 62, 227, 26);
		contentPane.add(bname);
		bname.setColumns(10);
		
		pub = new JTextField();
		pub.setBounds(137, 110, 229, 26);
		contentPane.add(pub);
		pub.setColumns(10);
		
		nop = new JTextField();
		nop.setBounds(140, 158, 226, 26);
		contentPane.add(nop);
		nop.setColumns(10);
		
		isseue = new JTextField();
		isseue.setBounds(140, 196, 226, 26);
		contentPane.add(isseue);
		isseue.setColumns(10);
		
		JButton btnAddBook = new JButton("Add Book");
		btnAddBook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					theQuery("insert into dbooks (bookid, bname, publisher, nop, booktype) values ('"+bookid.getText()+"', '"+bname.getText()+"','"+pub.getText()+"','"+nop.getText()+"','"+isseue.getText()+"')");
					System.out.print("Book added!");
				}catch(Exception ex) {
					System.out.print("Problem occured!");
				}
			}
		});
		btnAddBook.setBounds(55, 229, 117, 29);
		contentPane.add(btnAddBook);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				HomePage hp = new HomePage();
				hp.setVisible(true);
			}
		});
		btnBack.setBounds(214, 229, 117, 29);
		contentPane.add(btnBack);
	}
}
