package mysql;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class Borrow extends JFrame {

	private JPanel contentPane;
	private JTextField txtid;
	private JTextField txtname;
	private JTextField pub;
	private JTextField txtnop;
	private JTextField isseue;
	private JTextField usrname;
	private JTextField nameu;

	ResultSet rs,rss;
	private JTextField txtID;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Borrow frame = new Borrow();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public void theQuery (String query) {
		Statement st = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library","root","NEWPASS");
			st = con.createStatement();
			st.executeUpdate(query);
			JOptionPane.showMessageDialog(null,"Query executed!");
		}catch(Exception ex) {
			JOptionPane.showMessageDialog(null,ex.getMessage());
		}
	}
	
	/**
	 * Create the frame.
	 */
	
	public Borrow() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 793, 305);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblBookId = new JLabel("Book ID");
		lblBookId.setBounds(35, 29, 61, 16);
		contentPane.add(lblBookId);
		
		JLabel lblBookName = new JLabel("Book Name");
		lblBookName.setBounds(35, 73, 71, 16);
		contentPane.add(lblBookName);
		
		JLabel lblPublisher = new JLabel("Publisher");
		lblPublisher.setBounds(35, 122, 61, 16);
		contentPane.add(lblPublisher);
		
		JLabel lblNumberOfPages = new JLabel("Number of Pages");
		lblNumberOfPages.setBounds(35, 169, 118, 16);
		contentPane.add(lblNumberOfPages);
		
		JLabel lblIssueStatus = new JLabel("Book Type");
		lblIssueStatus.setBounds(35, 218, 107, 16);
		contentPane.add(lblIssueStatus);
		
		txtid = new JTextField();
		txtid.setBounds(170, 24, 220, 26);
		contentPane.add(txtid);
		txtid.setColumns(10);
		
		txtname = new JTextField();
		txtname.setBounds(170, 68, 220, 26);
		contentPane.add(txtname);
		txtname.setColumns(10);
		
		pub = new JTextField();
		pub.setBounds(170, 117, 220, 26);
		contentPane.add(pub);
		pub.setColumns(10);
		
		txtnop = new JTextField();
		txtnop.setBounds(170, 164, 220, 26);
		contentPane.add(txtnop);
		txtnop.setColumns(10);
		
		isseue = new JTextField();
		isseue.setBounds(170, 213, 220, 26);
		contentPane.add(isseue);
		isseue.setColumns(10);
		
		JButton btnBorrowBook = new JButton("Issue Book");
		btnBorrowBook.setBounds(100, 246, 117, 29);
		btnBorrowBook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Issue the book
				try {
					theQuery("insert into Borrow (bookid, bname, publisher, nop, booktype,UserID,Username,Name) values ('"+txtid.getText()+"', '"+txtname.getText()+"','"+pub.getText()+"','"+txtnop.getText()+"','"+isseue.getText()+"','"+txtID.getText()+"','"+usrname.getText()+"','"+nameu.getText()+"')");
					JOptionPane.showMessageDialog(null,"Book Issued!");
				}catch(Exception ex) {
					JOptionPane.showMessageDialog(null,"Problem occured!");
				}
			}
			
			
		});
		contentPane.add(btnBorrowBook);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.setBounds(229, 246, 117, 29);
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				HomePage hm = new HomePage();
				hm.setVisible(true);
			}
		});
		contentPane.add(btnCancel);
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setBounds(518, 68, 79, 16);
		contentPane.add(lblUsername);
		
		JLabel lblName = new JLabel("Name");
		lblName.setBounds(518, 104, 79, 16);
		contentPane.add(lblName);
		
		usrname = new JTextField();
		usrname.setBounds(589, 61, 130, 26);
		contentPane.add(usrname);
		usrname.setColumns(10);
		
		nameu = new JTextField();
		nameu.setBounds(589, 99, 130, 26);
		contentPane.add(nameu);
		nameu.setColumns(10);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Searching books
				try{
					Class.forName("com.mysql.jdbc.Driver").newInstance();
					//System.out.println("Installed");
					Connection conn1= DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "root", "NEWPASS");
					Statement stmt1=conn1.createStatement();
					
					int idbook = Integer.parseInt(txtid.getText());
					//String namebook = String.valueOf(txtname.getText());
					rss = stmt1.executeQuery("select * from dbooks where bookid="+ idbook);
					while(rss.next()){
						txtid.setText(rss.getString("bookid"));
					    txtname.setText(rss.getString("bname"));
						pub.setText(rss.getString("publisher"));
						txtnop.setText(rss.getString("nop"));
						isseue.setText(rss.getString("booktype"));
					}
					
				}catch(Exception ex){
					System.out.println("Problem occured.");
				
				}
			}
		});
		btnSearch.setBounds(389, 24, 99, 26);
		contentPane.add(btnSearch);
		
		JButton btnSearch_1 = new JButton("Search");
		btnSearch_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Student search
				try{
					Class.forName("com.mysql.jdbc.Driver").newInstance();
					//System.out.println("Installed");
					Connection conn1= DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "root", "NEWPASS");
					Statement stmt1=conn1.createStatement();
					
					int idbook = Integer.parseInt(txtid.getText());
					//String namebook = String.valueOf(txtname.getText());
					rss = stmt1.executeQuery("select * from Accounts where UserID="+ idbook);
					while(rss.next()){
						txtID.setText(rss.getString("UserID"));
						usrname.setText(rss.getString("Username"));
						nameu.setText(rss.getString("Name"));
					}
					
				}catch(Exception ex){
					System.out.println("Problem occured.");
				
				}
			}
		});
		btnSearch_1.setBounds(602, 156, 117, 29);
		contentPane.add(btnSearch_1);
		
		JLabel lblUserId = new JLabel("User ID");
		lblUserId.setBounds(518, 29, 61, 16);
		contentPane.add(lblUserId);
		
		txtID = new JTextField();
		txtID.setBounds(589, 24, 130, 26);
		contentPane.add(txtID);
		txtID.setColumns(10);
	}
}
